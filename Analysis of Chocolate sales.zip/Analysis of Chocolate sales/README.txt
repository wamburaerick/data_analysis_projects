Awesome Chocolates Products sales for six countries by different sales peole are analyzed by looking at;
1. Quick Statistics
2. Sales by country
3. Top 5 most Products by dollar units
4. Presence of anomalies using boxplot/scatterplot
5. Best Sales person by country
6. Profits by product (using products table)
7. Which products to discontinue? I used barplot
8. Dynamic country-level Sales Report

NOTE: I used xlwings to load data from excel hence rerunning the cells would encounter errors if respective dataset(namely: blank.xls) is not opened on sheet 2.

Credits: chandoo.org