The titanic survivers prediction dataset is from a competition on Kaggle and I did machine learning prediction.

There are two datasets train and test.

I preprocessed both datasets separately.

I tested four models and RandomForestClassifier came with acceptable Accuracy and cross validation.

Hence, my submission to Kaggle is named 'Erick_Submission.csv'

I got 0.75 prediction correct which is equal to 75%

Credits: Kaggle